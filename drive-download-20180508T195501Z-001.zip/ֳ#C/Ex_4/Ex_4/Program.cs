﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int digit = 0;
            int num = 0;
            int digitu = 0;
            int digitt = 0;

            Console.WriteLine("Please enter a digit from 1-9");
            digit = int.Parse(Console.ReadLine());

          //  Console.WriteLine("Please enter a number between 1-100");
           // num= int.Parse (Console.ReadLine());

          /*  do
            {
                while (num % 10 == digit && num / 10 == digit)

                    digitu = int.Parse (Console.ReadLine ());
                     digitu = num % 10;

                    digitt = int.Parse(Console.ReadLine());
                    num = num / 10;

                    Console.WriteLine("{0} {1}",digitt,digitu);
                    Console.ReadKey();

              
            } while (num > 0 && num<=99);

    */

            for (int i=1;i<=100; i++)
            {
                if (i%10==digit || i%10==digit)
                {
                    Console.WriteLine(i);
                }

            }

            Console.ReadKey();


        }
    }
}
