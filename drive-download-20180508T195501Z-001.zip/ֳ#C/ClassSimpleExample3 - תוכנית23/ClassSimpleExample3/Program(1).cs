﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassSimpleExample3
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person();               //default cTor
            person1.FirstName = Console.ReadLine(); 
            person1.LastName = Console.ReadLine();
            person1.Age = int.Parse(Console.ReadLine());
            person1.Address = Console.ReadLine();
            //Person person2 = new Person("Gadi", "Rosen");
            Person person2 = new Person(person1.FirstName, person1.LastName); // העמסה של 2 STRINGS.
            person2.Print1();
            Person person3 = new Person("Gadi", "Rosen", "Nahal Zohar 66 Modi'in"); // העמסה של 3 STRINGS. בHARD CODE.
            //Person person3 = new Person(person1.FirstName, person1.LastName, person1.Address);
            person3.Print2();

            Console.ReadKey();
        }
    }

    class Person
    {
        private string _firstName;
        public string FirstName
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }

        
        private string _lastName;
        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }

        
        private int _age;
        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                if (_age < 0)		//to avoid entering garbage detailes
                    _age = 0;
                else
                    _age = value;
            }
        }


        
        private string _id;
        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }


        
        private string _address;
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }


        public Person()
        {
        }
        

        public Person(string fName, string lName)
        {
            this._firstName = fName; // משתנה לוקאלי. 
            this._lastName = lName;
        }

        public Person(string fName, string lName, string address) // person 3.
        {
            this._firstName = fName; // משתנים לוקאליים מקבלים פרמטרים.
            this._lastName = lName;
            this._address = address;
        }


        public void Print1()
        {
            Console.Write("firstName = {0}\n" +
                          "lastName = {1}\n"  ,_firstName, _lastName);
                                                       
        }


        public void Print2()
        {
            Console.WriteLine("\nfirstName = {0}\n" +
                                             "lastName = {1}\n" +
                                             "address = {2}\n " , _firstName, _lastName, _address);

        }
    }
}
