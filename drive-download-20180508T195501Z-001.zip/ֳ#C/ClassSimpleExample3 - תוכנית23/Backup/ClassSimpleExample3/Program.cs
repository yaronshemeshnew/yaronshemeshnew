﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassSimpleExample3
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person("Gadi", "Rosen", 50, "Nahal Zohar 66 Modi'in");
            person.Print();
            person.Print("Gadi", "Rosen"); //function overloading
            Person person2 = new Person();
            person2.Print();
        }
    }

    class Person
    {
        private string _firstName;
        public string FirstName
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }

        
        private string _lastName;
        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }

        
        private int _age;
        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                if (_age < 0)		//to avoid entering garbage detailes
                    _age = 0;
                else
                    _age = value;
            }
        }


        
        private string _id;
        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }


        
        private string _address;
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }


        public Person()
        {
        }
        

        public Person(string fName, string lName, int age, string address)
        {
            this._firstName = fName;
            this._lastName = lName;
            this._age = age;
            this._address = address;
        }


        public void Print()
        {
            Console.Write("firstName = {0}\n" +
                          "lastName = {1}\n" +
                          "age = {2}\n" +
                          "address = {3}\n", _firstName, _lastName, _age, _address);
                                                       
        }


        public void Print(string p_firstName, string p_lastName)
        {
            Console.WriteLine("\nfirstName = {0}\n" +
                                             "lastName = {1}\n" , p_firstName, p_lastName);

        }
    }
}
