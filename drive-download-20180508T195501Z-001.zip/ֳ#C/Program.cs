﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Info
{
    class Program
    { 
        static void Main(string[] args)
        {
            string First_Name, Last_Name, Address;
            int age = 0;

            Console.WriteLine("Please enter your first name ");
            First_Name = Console.ReadLine();

            Console.WriteLine ("Please enter your Last Name");
            Last_Name = Console.ReadLine();

            Console.WriteLine("Please enter your Address");
            Address = Console.ReadLine();

            Console.WriteLine("Please enter your age");
            age = int.Parse(Console.ReadLine());


            Console.Write("\nthe deatils are:\n my first name is: {0} \n my last name is: {1}, my age is {4}",First_Name,Last_Name,Address,age );

            Console.WriteLine("Your name is {0} {1}, Your Address is: {2}, Your age is {3}", First_Name, Last_Name, Address, age);

            Console.ReadLine();

           

        }
    }
}
