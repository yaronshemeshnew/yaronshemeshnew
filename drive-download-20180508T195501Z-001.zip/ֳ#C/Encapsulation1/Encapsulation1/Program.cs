﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Encapsulation1 // המרחב השמי. 
{
    class Program //מחלקה ראשונה.
    {
        static void Main(string[] args)
        {
            Person person; // הצהרה.
            person = new Person(); // הקצאת מופע בזיכרון. 
            
                                //     בשם PERSON


}




        // = new Person(); //Person 1, מחלקה.  אות גדולה.
    } }              // person 2.  שם האובייקט..
}                     // אובייקט= מופע של המחלקה.     
                      // Case Sensitive. 
                      // new, הקצאה בזיכרון למופע שנקרא person 
                      // instance. מופע.
                      // אובייקט person מטיפוס Person
                      // person= new Person();

