﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Encapsulation1
{
    class Person
    {
        private string fName;
        private string lName;
        private string address;
        public int age; // ניתן לראות את זה בPROGRAM. 
        

    }
}
