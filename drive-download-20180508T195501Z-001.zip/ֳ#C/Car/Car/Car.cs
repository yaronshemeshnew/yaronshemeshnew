﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Car_ENCAPUSLATION
{
    class Car
    {
        private string id_number;
        public string ID_NUMBER
        {
            get
            {
                return id_number;

            }

            set
            {
                id_number = value;
            }

        }


        private int year;
        public int YEAR
        {
            get
            {
                return year;
            }

            set
            {
                year = value;
            }
        }

        private double gaz;
        public double GAZ
        {
            get
            {
                return gaz;
            }

            set
            {
                if (gaz < 0)
                    gaz = 0;
                else
                    gaz = value;

            }

        }

        public Car()
        { }

       


        public bool IsVaild(int km)
        {
            if ((km/10)<=GAZ)
                return true;
            else
                return false;
  
        }

        public void Print()
        {
            Console.WriteLine("the car details are : {0,6}-{1,4}-{2,4} ", ID_NUMBER, YEAR, GAZ);
        }

    }



}


