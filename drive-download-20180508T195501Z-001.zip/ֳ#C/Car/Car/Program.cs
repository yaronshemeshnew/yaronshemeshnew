﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Car_ENCAPUSLATION
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car(); //default cTor

            Console.Write("Enter car ID : ");
            car.ID_NUMBER = Console.ReadLine();
            Console.Write("Enter Car's year : ");
            car.YEAR = int.Parse(Console.ReadLine());
            Console.Write("Enter Car's gaz : ");
            car.GAZ = double.Parse(Console.ReadLine());

            car.Print();

            Console.Write("Enter your distance : ");
            int km = int.Parse(Console.ReadLine());

            if (car.IsVaild(km))
            //bool isValid = car.IsVaild(km);
            //if(isValid)
                Console.WriteLine("you have enough gaz");
            else
                Console.WriteLine("you haven't enough gaz");

            
        }
    }

}
