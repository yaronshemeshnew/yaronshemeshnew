﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator_Stasya
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 0, num2 = 0, operation = 0;
            string begin = "n";
            Calculator(out num1, out num2, out operation, out begin);
        }

        private static void Calculator(out int num1, out int num2, out int operation, out string begin)
        {
            do
            {
                Console.WriteLine("Enter 2 numbers that you want to calculate:");
                num1 = int.Parse(Console.ReadLine());
                num2 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Choose a mathematical operation according to the following menu:\n");
                // Console.WriteLine();
                Console.WriteLine("Press number '1' for addition (+)");
                Console.WriteLine("Press number '2' for subtraction (-)");
                Console.WriteLine("Press number '3' for division (/)");
                Console.WriteLine("Press number '4' for multiplication (*)");
                operation = int.Parse(Console.ReadLine());
                Console.WriteLine();


                Console.WriteLine("You entered numbers {0} and {1}", num1, num2);  // הדפסת מספרים אותם המשתמש בחר לחשב


                switch (operation)
                {
                    case 1:
                        {
                            Console.WriteLine("You choosed operation (+)\n");
                            Console.WriteLine("The result is: {0}+{1}={2}\n", num1, num2, num1 + num2);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("You choosed operation (-)\n");
                            Console.WriteLine("The result is: {0}-{1}={2}\n", num1, num2, num1 - num2);
                            break;
                        }
                    case 3:
                        {
                            if (num2 != 0)
                            {
                                Console.WriteLine("You choosed operation (/)\n");
                                Console.WriteLine("The result is: {0}/{1}={2}\n", num1, num2, num1 / num2);
                            }
                            else
                            {
                                Console.WriteLine("You choosed operation (/)\n");
                                Console.WriteLine("***! IT IS FORBIDDEN TO DIVIDE BY ZERO !***\n\n\n");
                            }
                            break;
                        }
                    case 4:
                        {
                            Console.WriteLine("You choosed operation (*)\n");
                            Console.WriteLine("The result is: {0}*{1}={2}\n", num1, num2, num1 * num2);
                            break;
                        }
                    default:
                        Console.WriteLine("You entered a wrong choose");
                        break;
                }
                Console.WriteLine("If you want to continue calculating type 'y' if not type 'n' ");
                begin = Console.ReadLine();
                Console.Clear();

            }
            while (begin == "y");
        }
    }
}
