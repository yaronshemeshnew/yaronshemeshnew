﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Grades
{
    class Program
    {
        static void Main(string[] args)
        {
            int grade1 = 0, grade2 = 0, grade3 = 0; // בערך התחלתי לאתחל את הציון.

            string name = "abc"; // string: מחרוזת של תווים, של char

            double avg = 0; // הממוצע לא חייב להיות שלם.

            Console.WriteLine("Please enter your name");
            name = Console.ReadLine();

            Console.WriteLine("Enter grade 1");
            grade1 = int.Parse(Console.ReadLine());       //,קולט את הציון וממיר מסטרינג לint. 
                                                          // ביצוע קסטינג
            Console.WriteLine("Enter grade 2");
            grade2 = int.Parse(Console.ReadLine());       //,קולט את הציון וממיר מסטרינג לint. 

            Console.WriteLine("Enter grade 3");
            grade3 = int.Parse(Console.ReadLine());       //,קולט את הציון וממיר מסטרינג לint. 


            
            avg = (grade1+ grade2 + grade3) / 3;


            if (avg > 80)
            {
                avg = avg + (avg * 1.1);
                Console.WriteLine("Well Done");
            }
            else if (avg >= 60 && avg <= 80)
                Console.WriteLine("Not bad");
            else if (avg >= 40 && avg <= 60)
                Console.WriteLine("Has To Improved");
            else
                Console.WriteLine("Failed");


            Console.ReadKey(); //משאיר את מסך התוכנית ולא יוצא מזה.



            /*if (grade > 90)
                Console.WriteLine("Excellent Student");  // one commend no need { }.
            else if (grade > 70 && grade <= 90) // צריך ששתי התנאים יהיו אמת.
                Console.WriteLine("Good Student");
            else if (grade > 50 && grade <= 70)
                Console.WriteLine("Not Good Enough");
            else  // else , מה שלא עונה על הקריטריונים האחרונים 
                Console.WriteLine("The Student Failed");

            Console.ReadKey(); //משאיר את מסך התוכנית ולא יוצא מזה.

    */
            // כולל את כל טווח האפשרויות מ0 עד 100. לכן יש שימוש גם בשווה.

        }
    }
}
