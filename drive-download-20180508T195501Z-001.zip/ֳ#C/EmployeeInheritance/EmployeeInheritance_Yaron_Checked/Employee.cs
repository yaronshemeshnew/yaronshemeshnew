﻿//base class Employee
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeeInheritance
{
    class Employee
    {
        private int id;
        private string f_name,l_name;
        private int darga;
        private double base_salary;
       
        public int Id { get { return id; } set { id = value; } }

        public string F_name{ get{ return f_name;} set { f_name = value; } }

        public string L_name{ get{ return l_name; }set {l_name = value; } }

        public int Darga { get { return darga; } set{ darga = value; } }

        public double Base_salary { get {return base_salary; }  }


        public Employee() //default ctr.
        {

        }
        public Employee(int id,string fname,string lname,double basesalary)
        {
            this.id = id;
            this.f_name = fname;
            this.l_name = lname;
            this.base_salary = basesalary;
            this.darga = 36;
        }
        public void IncRanc()
        { this.darga++; }



    }
}
