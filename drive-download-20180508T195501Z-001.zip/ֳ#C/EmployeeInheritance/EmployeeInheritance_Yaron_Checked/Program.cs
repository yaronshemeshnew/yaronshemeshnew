﻿//program creates array of objects from type Worker class and prints them
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeeInheritance
{
    class Program
    {

        //נראה לי שהתוכנית הועתקה מילנה. בכל מקרה אני מקווה שאתה מבין את מה שכתבת
        static void Main(string[] args)
        {
            // הכרזה וזימון פונקציה לצורך הדפסה.
            Employee emp2;
            Manager manager;
            InitializeEmployee(out emp2, out manager);


            // יצירת מערך של 3 עובדים.
            Employee[] emp = new Employee[3];

            InitializeEmployee2(emp);


            Console.ReadLine();
        }


        private static void InitializeEmployee(out Employee   emp,out Manager man)
        {
           emp = new Employee(111, "ggg", "jjj", 5000.0);
           man= new Manager(222, "hhh", "kkk", 7000.0,10000.0);

            PrintEmployee(emp,man);
        }

        // קליטת פרטי העובד.

        private static void InitializeEmployee2(Employee[] emp)
        {
            
            for (int i=0;i<emp.Length;i++)
            {
                int id;
                string fname, lname;
                double salary;
                
                Console.Write("Enter id:");
                id = int.Parse(Console.ReadLine());
                Console.Write("Enter first name:");
                fname = Console.ReadLine();
                Console.Write("Enter last name:");
                lname = Console.ReadLine();
                Console.Write("Enter base salary:");
                salary = double.Parse(Console.ReadLine());

                emp[i] = new Employee(id,fname,lname,salary);
            }
            PrintEmployee2(emp);
          
        }
    
        /// <summary>
        ///  הדפסת פרטי העובד
        /// </summary>
        /// <param name="emp"></param>
        private static void PrintEmployee2(Employee[] emp)
        {
            for (int i = 0; i < emp.Length; i++)
            
                Console.WriteLine("the details of {0} employee:id:{1},First name is:{2},Last name={3},Salary is:{4},Darga is{5}",i+1, emp[i].Id, emp[i].F_name, emp[i].L_name, emp[i].Base_salary,emp[i].Darga);
        }
           
        private static void PrintEmployee(Employee em,Manager man)
       
        {
            Console.WriteLine("Employee:your first name:{0}, last name:{1},id:{2} ,darga:{3},salary:{4}", em.F_name, em.L_name, em.Id, em.Darga,em.Base_salary);
            Console.WriteLine("Manager:your first name:{0}, last name:{1},id:{2} ,darga: {3},salary:{4}", man.F_name,man.L_name,man.Id,man.Darga,man.Salary);

        }

        
    }
}
