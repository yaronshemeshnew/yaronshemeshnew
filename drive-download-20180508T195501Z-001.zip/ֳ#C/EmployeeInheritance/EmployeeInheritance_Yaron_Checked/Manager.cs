﻿//derived class
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeeInheritance
{
    class Manager:Employee
    {
        private double bonus;
        private string car_number;
        private string options;
       

        public double Bonus { get { return bonus; } set { bonus = value; }}
        public string Car_number { get { return car_number; } set { car_number = value; } }
        public string Options { get { return options; } set { options = value; } }


        public Manager(int id,string fname,string lname,double base_salary,double bon):base(id,fname,lname,base_salary)
        {
            this.Darga = 42;
            this.bonus = bon;
        }

        public double Salary
        {
            get { return (Base_salary + (this.bonus / 12)); }
        }
    }

}
