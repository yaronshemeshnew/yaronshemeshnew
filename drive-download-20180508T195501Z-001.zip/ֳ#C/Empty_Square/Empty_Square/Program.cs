﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Empty_Square
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the size of the square");
            int n = int.Parse(Console.ReadLine());

            /* another way to do square. 
            //Upper Part of the square. אני יוצר את השורה הראשונה בחלק.
            for (int i = 0; i < n; i++)
                Console.Write("*");
            Console.Write("\n");
            */

            //Middle Part. אני יוצר חלק אמצעי שמורכב מלולאה מקוננת, עמודה בתוך שורה

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    if (i == 1 || i == n || j == 1 || j == n)
                        Console.Write("*");
                    else
                        Console.Write(" ");

                }
                Console.WriteLine();
            }

            Console.ReadKey();

            /*for (int i = 0; i < n - 2; i++)   //n-2= יוצר לי את מס' השורות בחלק האמצעי שזה בעצם החלק השלם פחות הקצוות
            {
                Console.Write("*"); // n-2 שורות שיש בתחילת שורה *

                for (int j = 0; j < n - 2; j++)
                    Console.Write(" ");

                Console.Write("*");
                
                Console.Write("\n"); //יורד שורה אחרי כל שורה, מבצע אנטר.
            }
                
    */


            /*
            //Lower Part.
            for (int i = 0; i < n; i++) //אני יוצר את השורה האחרונה בחלק
                Console.Write("*");
            Console.Write("\n");

            Console.ReadLine();
           */
        }



    }
}
