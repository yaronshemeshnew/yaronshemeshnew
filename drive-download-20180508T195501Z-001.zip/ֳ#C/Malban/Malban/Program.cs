﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


//Programer Name: Yaron Shemesh
// התוכנית תיצור מלבן בגודל   3 על 5
namespace Malban
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    Console.Write("*");
                    //הפקודה צריכה להיות write כי אני כותב את הכוכביות באותה שורה
                }

                Console.WriteLine(); //כדי שירד שורה בין שורה לשורה בריבוע
            }
            Console.ReadLine();


        }
    }
}
