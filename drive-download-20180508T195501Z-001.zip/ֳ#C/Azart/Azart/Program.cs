﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/// <summary>
/// programmer name: Yaron Shemesh.
/// התוכנית תחשב את העצרת של המס' שהמשתמש מקליד.
/// </summary>

namespace Azart
    {
        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Please insert a number");
                int n = int.Parse(Console.ReadLine());
                int assembly = 1;  // קביעת ערך התחלתי לעצרת שלי


                for (int i = 1; i <= n; i++)
                {
                    assembly *= i; //assembly= assembly*i, חישוב העצרת
                                    // עצרת= לערך ההתחלתי שלה כפול המונה' 
                }                   //1*2*3*4 עד למס' שאותו קלטנו 
                Console.WriteLine("n! is : {0}", assembly);
                Console.ReadKey();


            }
        }
    }


