﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ribow_a_b
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 0;
            Console.Write("Please insert number a: ");
             a = int.Parse(Console.ReadLine());

            Console.Write("Please insert number b: ");
             b = int.Parse(Console.ReadLine());

            //Console.Write("a= {0} , b= {1} ", a, b);

            for (int i = 0; i < (a * b); i++)
            {
                for (int j = 0; j < (a * b); j++)
                {
                 
                        Console.Write("*");
                        //הפקודה צריכה להיות write כי אני כותב את הכוכביות באותה שורה
                }

               Console.WriteLine(); //כדי שירד שורה בין שורה לשורה בריבוע
            }
                Console.ReadLine();
        
        }
    }
}
