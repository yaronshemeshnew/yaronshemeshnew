﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Encapsulalion
{
    class Employee
    {
        private string _firstName;
        public string FirstName //properties.
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }


        private string _lastName;
        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }


        private int _age;
        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                if (_age < 0)		//to avoid entering garbage detailes
                    _age = 0;
                else
                    _age = value;
            }
        }



        private string _id;
        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }


        private string _address;
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }




        public Employee()
        {



        }



        public Employee(string firstname, string lastname)
        {
            this._firstName = firstname;
            this._lastName = lastname;

        }

        public Employee(string firstname, string lastname, string address, int id, int age)
        {
            this._firstName = firstname;
            this._lastName = lastname;
            this._address = address;

        }

        public Employee(string Fname, string Lname, string Address)
        {
            this._firstName = Fname;
            this._lastName = Lname;
            this._address = Address;
        }







        public void Print()
        {
            Console.Write("firstName = {0}\n" +
                          "lastName = {1}\n", _firstName, _lastName);

        }
        public void Print(int age)
        {
            Console.Write("age is:{0} ", Age);

        }


        public void Print2()
        {
            Console.WriteLine("\nfirstName = {0}\n" +
                                             "lastName = {1}\n" +
                                             "address = {2}\n ", _firstName, _lastName, _address);




        }
    }
}
