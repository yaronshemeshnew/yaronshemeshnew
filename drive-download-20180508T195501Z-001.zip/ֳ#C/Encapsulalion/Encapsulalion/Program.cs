﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Encapsulalion
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee();
            employee.FirstName = Console.ReadLine();
            employee.LastName = Console.ReadLine();
            employee.Age= int.Parse(Console.ReadLine());
            employee.Age = int.Parse(Console.ReadLine());
            employee.Address = Console.ReadLine();

            employee.Print();

            Employee employee2 = new Employee("Yaron", "Shemesh", "Har Mazada 111/24 Ashdod Israel"); // העמסה של 2 STRINGS.

            employee2.Print(7);

           
            Employee employee3 = new Employee ("Gadi", "Rosen", "Nahal Zohar 66 Modi'in"); // העמסה של 3 STRINGS. בHARD CODE.


            //Employee employee3 = new Employee (employee.FirstName, employee.LastName, employee.Address);

            employee3.Print(123456);


            Console.ReadKey();





            }
        }

    

}
