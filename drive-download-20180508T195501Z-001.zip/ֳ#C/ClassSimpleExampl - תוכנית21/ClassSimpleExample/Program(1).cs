﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassSimpleExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person();
            
            p.Print();
        }
    }

    class Person
    {
        private string _firstName ;  
       
        private string _lastName ;   

        private int _age ;

        private string _id ;

        private string _address ; 

        public void Print()
        {
            Console.Write("Please enter your first name : ") ;
            _firstName = Console.ReadLine();
            Console.Write("Please enter your last name : ");
            _lastName = Console.ReadLine();
            Console.Write("Please enter your age : ");
            _age = int.Parse(Console.ReadLine());
            Console.Write("Please enter your id : ");
            _id = Console.ReadLine();
            Console.Write("Please enter your address : ");
            _address = Console.ReadLine();
            Console.Write("first name = {0}\n" +
                                   "last name = {1}\n" +
                                   "age = {2}\n" +
                                   "id = {3}\n" +
                                   "address = {4}\n", _firstName, _lastName,
                                                                _age, _id, _address);
        }
    }

}
