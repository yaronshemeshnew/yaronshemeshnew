﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Calculate_Method
{
    class Program
    {
            static void Main(string[] args)
            {
                int num1 = 0, num2 = 0;
                char c = 'a';
                //double result = 0;

                Console.WriteLine("Please enter 2 numbers:");
                num1 = int.Parse(Console.ReadLine());

                num2 = int.Parse(Console.ReadLine());

                Console.WriteLine("Please enter the operation sign:");
                c = char.Parse(Console.ReadLine()); //חובה לעשות parse למשתנה מסוג char גם אם הוא מוגדר כchar

                Calc(num1, num2, c); // קריאה לפונקציה
                                     //מה שבסוגריים זה מה שהפונקציה מקבלת
             }


            public static void Calc(int a, int b, char c)  // היישום של הפונקציה  
            {                                               // gets a,b, c.  מהפונקציה הראשית
                double result = 0;
                switch (c)
                {
                    case '+':
                        result = a + b; break;
                    case '-':
                        result = a - b; break;
                    case '*':
                        result = a * b; break;
                    case '/':
                        result = a / b; break;
                }

                if (result != 0)
                    Console.Write(result);
                else
                    Console.Write("This is wrong");

                Console.ReadKey();


            }
        }
    }

