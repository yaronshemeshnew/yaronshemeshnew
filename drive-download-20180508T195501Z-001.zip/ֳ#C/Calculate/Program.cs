﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 0, num2 = 0;
            char c = 'a';
            double result = 0;

            Console.WriteLine("Please enter 2 numbers:");
            num1 = int.Parse(Console.ReadLine());
            num2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Please enter the operation sign:");
            c = char.Parse(Console.ReadLine()); //חובה לעשות parse למשתנה מסוג char גם אם הוא מוגדר כchar

            switch (c)
            {
                case '+':
                    result = num1 + num2; break;
                case '-':
                    result = num1 - num2; break;
                case '*':
                    result = num1 * num2; break;
                case '/':
                    result = num1 / num2; break;

            }



            if (result != 0)

                Console.WriteLine("Your Result Is Correct: {0}", result);

            else
                Console.WriteLine("Your Result Is Wrong: {0}", result );

            Console.ReadLine();

        }

    }
}



