﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Example
{
    public static void Main()
    {
        int caseSwitch = 0;
        double result = 0;
        int num1 = 0, num2 = 0;

        Console.WriteLine("Please enter num1");
        num1 = int.Parse(Console.ReadLine());
        Console.WriteLine("Please enter num2");
        num2 = int.Parse(Console.ReadLine());

        Console.WriteLine("Please enter the number of case");
        caseSwitch = int.Parse(Console.ReadLine());

        switch (caseSwitch)
        {
            case 1:
                Console.WriteLine("Case 1, +");
                result = num1 + num2;
                break;
            case 2:
                Console.WriteLine("Case 2, -");
                result = num1 - num2;
                break;
            case 3:
                Console.WriteLine("Case 3, /");
                result = num1 / num2;
                break;
            case 4:
                Console.WriteLine("Case 4, *");
                result = num1 * num2;
                break;
            default:
                Console.WriteLine("Default case");
                break;


        }

        Console.WriteLine("the result is : {0}", result);
        Console.ReadLine();
    }
}
