﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassSimpleExample2
{
    class Program
    {
        static void Main(string[] args)
        {
            // הכנסת ערכים למשתנים. יש פנייה לפונקציה. 
            Person p = new Person();
            Console.Write("Please enter your first name: ");
            p.FirstName = Console.ReadLine();
            Console.Write("Please enter your last name: ");
            p.LastName = Console.ReadLine();
            Console.Write("Please enter your id: ");
            p.ID = int.Parse(Console.ReadLine());
            Console.Write("Please enter your age: ");
            p.Age = int.Parse(Console.ReadLine());
            Console.Write("Please enter your address: ");
            p.Address = Console.ReadLine();
            p.Print();
            //p.Print(p.FirstName, p.LastName, p.Age, p.Address); // פנייה לפונקציה. 
        }
    }




    class Person
    {
        //Property הכנסת ערכים דרך הPROPERTIES שניגשו לPRIVATE. 
        private string _firstName;
        public string FirstName // התחלה של PROPERTIE.
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }

        
        private string _lastName;
        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }

       
        private int _age; // לא ניתן לגשת אל המשתנה אלא רק עי Properties. 
        public int Age // מאפיין. אות גדולה.
        {
            get
            {
                return _age;
            }
            set
            {
                if (_age < 0)		//to avoid entering garbage detailes
                    _age = 0;        // כדי למנוע ערך שלילי
                else
                    _age = value;  // כל משתנה שהוא שגדול מ0. 
            }
        }

        
        //public string id;
        private int _id;
        public int ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }


        //public string address;
        private string _address;
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }

        //overloading, העמסה, חתימה שונה של הפונקציה. 
        public void Print()
        {
            
            Console.Write("firstName = {0}\n" +
                          "lastName = {1}\n" +
                          "id = {2}\n" +
                          "age = {3}\n" +
                          "address = {4}\n", _firstName, _lastName, _id,
                                                       _age, _address);
        }


        public void Print(string p_firstName, string p_lastName, int p_age, string p_address)
        {
            Console.WriteLine("\nfirstName = {0}\n" +
                                          "lastName = {1}\n" +
                                          "age = {2}\n" +
                                          "address = {3}\n", p_firstName, p_lastName, p_age,
                                                                       p_address);

            //משתנים לוקאליים.
        }
    }
}
