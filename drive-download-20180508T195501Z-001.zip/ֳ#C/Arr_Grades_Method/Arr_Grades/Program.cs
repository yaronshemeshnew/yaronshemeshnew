﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Arr_Grades 
{
    internal class Program //שם המחלקה. 
    {
      
        private static void Main(string[] args) // שם הפונקציה.
        {

            int[] arr = new int[5];
            for (int i = 0; i < arr.Length; i++)  //קולט את הציונים במערך.
            {
                Console.Write("Enter grade : ");
                arr [i] = int.Parse(Console.ReadLine());
            }


            foreach (int grade in arr)  // מדפיס את הציונים של המערך.
                 Console.Write ("{0} ",grade);

             
            Average(arr);  //מחשב את הממוצע באמצעות פונקציה
                           // get the grades from the array


            Console.ReadKey();
        }

        private static void Average(int[] arr)
        {
            double avg = 0;
            int sum = 0;
            for (int i = 1; i< 4; i++)
            {
                sum+= arr [i];
                avg = sum / 4;
            }
            Console.Write ("\nThe Sum is: {0}, The Average is: {1}",sum,avg);
            
        }
       

    }
}











