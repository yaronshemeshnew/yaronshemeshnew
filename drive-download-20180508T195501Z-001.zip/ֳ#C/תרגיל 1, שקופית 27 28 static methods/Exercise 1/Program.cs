﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StructWithFunctions
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your first name:");
            string frstname = Console.ReadLine();
            Console.Write("Enter your last name:");
            string lstName = Console.ReadLine();
            Console.Write("Enter your address:");
            string address = Console.ReadLine();
            Console.Write("Enter your age:");
            int age = int.Parse(Console.ReadLine());


            // שלוש העמסות שונות, חתימה שונה. 

            Console.Write("\n");


            PrintDetails(frstname, lstName, address, age); //string,string,string,int.
            Console.WriteLine(); // רווח בין הקריאות השונות לפונקציה

            PrintDetails(frstname, lstName); // string, string.
            Console.WriteLine();

            PrintDetails(address, age); //string,int.

        }



        //פונקציה הקולטת 4 פרמטרים ומדפיסה אותם. 
        private static void PrintDetails(string frstname, string lstName, string address, int age)
        {
            Console.WriteLine("My first name is: {0} \n" +
                              "My last name is: {1}\n" +
                              "My address is: {2}\n" +
                              "My age is : {3}", frstname, lstName, address, age);

        }

        //METHOD= פונקציה. שיטה. 






        private static void PrintDetails(string frstname, string lstName)
        {
            Console.WriteLine("My first name is: {0} \n" +
                             "My last name is: {1}\n"
                             , frstname, lstName);


        }



        private static void PrintDetails(string address, int age)
        {

            Console.WriteLine("My address is: {0}\n" +
                              "My age is : {1}", address, age);

        }





    }




}