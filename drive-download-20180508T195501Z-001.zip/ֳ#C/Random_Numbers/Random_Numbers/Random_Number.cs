﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Random_Numbers
{
    class Guess_me
    {
        static void Main(string[] args)
        {
            int num = 0;
            int count = 0;
            Random random = new Random();
            int randomNumber = random.Next(0, 100);

            Console.WriteLine("the random number is: {0}", randomNumber);

//            Console.WriteLine("Please guess the computer's number");
//            num = int.Parse (Console.ReadLine());

            do
            {
                Console.WriteLine("Please guess the computer's number");
                num = int.Parse(Console.ReadLine());

                    
            } while (num != randomNumber);


            if (num > randomNumber)
            {
                Console.WriteLine("the number is too big");
                count++;
            }
            else if (num < randomNumber)
            {
                Console.WriteLine("The number is too small");
                count++;
            }
            else if (num == randomNumber)
            {
                Console.WriteLine("you guessed right the number");
                count++;
            }
            Console.WriteLine("The number of gusses the user did is: {0}", count);
            Console.ReadKey();

        }
    }
}
