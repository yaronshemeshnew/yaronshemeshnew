﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NEW_GRADES
{
    class PrintNum1To100_versions
    {
        static void Main(string[] args)
        {
            
            for (int i = 10; i <= 100; i += 2)
            {
                Console.WriteLine(i);
            }
            // טווח ההכרה של הממוצע יהיה גם מחוץ ללולאה ולכן הגדרנו את זה מחוץ ללולאה.
            Console.ReadKey();


        }
    }
}