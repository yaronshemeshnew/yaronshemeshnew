﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Date
{
    class Date
    {
        private int Day;
        public int DAY
        {
            get
            {
                return Day;

            }

            set
            {
                Day = value;
            }

        }


        private int Month;
        public int MONTH
        {
            get
            {
                return Month;

            }

            set
            {
                Month = value;
            }

        }

        private int Year;
        public int YEAR
        {
            get
            {
                return Year;

            }

            set
            {
                Year = value;
            }
        }


        public Date ()
        { }

        public Date(int Day, int Month, int Year)
        {
            this.Day = Day;
            this.Month = Month;
            this.Year = Year;



        }

       

        public void Print ()
        {
            Console.WriteLine("The full date is: {0}/{1}/{2}", Day, Month, Year);


        }


        public bool IsValid(int Day, int Month, int Year)
        {
            if ((Day > 0 && Day <= 31) && (Month > 0 && Month <= 31) && (Year > 0 && Year <= 12))
                return true;
            else
                return false;

        }



    }



}
