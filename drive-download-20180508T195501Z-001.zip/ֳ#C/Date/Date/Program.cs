﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Date
{
    class Program
    {
        static void Main(string[] args)
        {
            Date date = new Date(10,11,1989);

            Console.WriteLine("Please insert the date:");
            date.DAY = int.Parse(Console.ReadLine());
            date.MONTH = int.Parse(Console.ReadLine());
            date.YEAR= int.Parse(Console.ReadLine());

            date.Print();

            if (date.IsValid(date.DAY, date.MONTH, date.YEAR))
                Console.Write("The date is correct");
            else
                Console.Write("The date is wrong");




            



        }
    }
}
