﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 0, num2 = 0;
            int option = 0, result = 0;


            Console.Write("Enter 2 numbers ");
            num1 = int.Parse(Console.ReadLine());
            num2 = Convert.ToInt32 (Console.ReadLine());

            Console.Write("Please choose your option");
            option = int.Parse(Console.ReadLine());

            switch (option)
            {
                case 1:
                    result = num1 + num2;
                    break;

                case 2:
                    result = num1 - num2;
                    break;

                case 3:
                    result = num1 / num2;
                    break;

                case 4:
                    result = num1 * num2;
                default:
                    Console.WriteLine("invaild numbers");
                    break;
            }

            }


        }
    }
}
