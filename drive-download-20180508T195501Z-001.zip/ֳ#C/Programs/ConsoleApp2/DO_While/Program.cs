﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DO_While
{
    class Program
    {
        static void Main(string[] args)
        {
            //string name = ""; //איפוס המשתנה 
            //do
            //{
            //    Console.Write("Enter your name:"); 
            //    name = Console.ReadLine();  //מותר להצהיר את זה ככה.
            //    //Console.WriteLine(name);  //sdsdsds 

            //    Console.Write("Enter your age:");
            //    int age = int.Parse(Console.ReadLine()); // הדפולט של המשתנה זה סטרינג ולא int. לכן עושים המרה.
            //    //Console.WriteLine(age); 

            //} while (name!= "Yaron"); //מכיוון שהצהרנו על הname מחוץ ללולאה.


            for (int i=0;i<5;i++)  //קולט 5 פעמים מ0 עד 4.
            {
                Console.Write("Enter a number: ");
                int number = int.Parse(Console.ReadLine());
                Console.WriteLine("This is the {0} statement", number);

            }

            Console.ReadKey();
        }
    }
}
