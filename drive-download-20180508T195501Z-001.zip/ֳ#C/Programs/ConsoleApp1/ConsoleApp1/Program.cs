﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Grades__Calculation
{
    class Program
    {
        static void Main(string[] args)
        {
            int grade1 = 0, grade2 = 0, grade3 = 0; // בערך התחלתי לאתחל את הציון.
            int count = 0; //מונה לספירת הציונים
            int sum = 0;
            string name = "abc"; // שם של הסטודנט. string: מחרוזת של תווים, של char
            double avg = 0.00; // הממוצע לא חייב להיות שלם.

            Console.WriteLine("Please enter your name");
            name = Console.ReadLine();

            Console.WriteLine("Enter grade 1");
            grade1 = int.Parse(Console.ReadLine());       //,קולט את הציון וממיר מסטרינג לint. 
            count++;  //אחרי הקלדה של ציון מוסיף אחד.

            Console.WriteLine("Enter grade 2");
            grade2 = int.Parse(Console.ReadLine());       //,קולט את הציון וממיר מסטרינג לint. 
            count++;

            Console.WriteLine("Enter grade 3");
            grade3 = int.Parse(Console.ReadLine());       //the deadult is string וצריך להמיר אותו לטיפוס אחר 
            count++;

            avg = (grade1 + grade2 + grade3) / 3;
            
            


            Console.WriteLine("student name: {0}", name);

            if (avg > 80)
            { // יותר מפקודה אחת.
                avg *= 1.1;
                Console.WriteLine("Well Done");
            }
            else if (avg >= 60 && avg <= 80)
                Console.WriteLine("Not bad");
            else if (avg >= 40 && avg <= 60)
                Console.WriteLine("Has To Improved");
            else
                Console.WriteLine("Failed");


            Console.ReadKey(); //משאיר את מסך התוכנית ולא יוצא מזה.

            //Console.WriteLine("the number of times that the grade was entered is: {0}", count);
            //Console.WriteLine("the avg is: {0}", avg);



            /*
            int i = 10;
            for (; i <= 100; i++)
            {
                Console.ReadLine(grade1);
                Console.WriteLine("The numbers are: ", grade1);
            }
        
              */
              



    }
    }
}
