﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hello_World
{
    class My_First_Program
    {
        static void Main(string[] args)
        {
            int num = 0; //Variable Decleration. הגדרה על משתנה num מטיפוס int ונתינת ערך התחלתי בשם 0
            Console.Write("Please enter a number:");
            num = int.Parse(Console.ReadLine()); //שינוי הערך. קודם מבצע את מה שבסוגריים ואחכ את ההמרה לnum
            Console.WriteLine("The number is : {0}",num);
            Console.ReadLine();
        }
    }

}




