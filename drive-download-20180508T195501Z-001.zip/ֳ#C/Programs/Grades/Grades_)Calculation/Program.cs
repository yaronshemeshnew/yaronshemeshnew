﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Programe Name: Yaron Shemesh.
//
namespace NEW_GRADES
{
    class Program
    {
        static void Main(string[] args)
        {
            int grade1 = 0, grade2 = 0, grade3 = 0; // בערך התחלתי לאתחל את הציון.
            int count = 0; //מונה לספירת הציונים
            string name = "abc"; // שם של הסטודנט. string: מחרוזת של תווים, של char
            double avg = 0.00; // הממוצע לא חייב להיות שלם.

            do {
                Console.Write("Please enter your name");
                name = Console.ReadLine();
                Console.WriteLine("Enter grade  between 0-100");
                grade1 = int.Parse(Console.ReadLine());       //,קולט את הציון וממיר מסטרינג לint. 
                Console.WriteLine("Enter grade  between 0-100");
                grade2 = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter grade  between 0-100");
                grade3 = int.Parse(Console.ReadLine());
                count++;  //אחרי הקלדה של ציון מוסיף אחד.
                avg = (grade1 + grade2 + grade3) / 3;
            } while (count < 3);

            //avg /= count;

             Console.WriteLine("the count is: {0}", count);

            if (avg > 80 && avg<=100)
            {
                avg = avg + (avg * 1.1);
                Console.WriteLine("Well Done, {0}, your avg is:{1}",name,avg);
            }
            else if (avg >= 60 && avg <= 80)
                Console.WriteLine("Not bad, {0} your avg is: {1}",name,avg);
            else if (avg >= 40 && avg <= 60)
                Console.WriteLine("{0} Has To Improved, your avg is: {1}",name,avg);
            else if (avg>100)
                Console.WriteLine("Error, Please write correct input");
            else
                Console.WriteLine("Failed");

            

            Console.ReadKey(); //משאיר את מסך התוכנית ולא יוצא מזה.

            







        }
    }
}


