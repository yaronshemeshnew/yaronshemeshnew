﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintNameAndAverageFunc
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ex1
            //Console.Write("Enter your name : ");
            //string name = Console.ReadLine();
            //Console.Write("Enter your age : ");
            //int age = int.Parse(Console.ReadLine());
            //Print(name, age);

            //Ex2
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int sum = CalculateNumbers(num1, num2);
            Console.WriteLine("The result is : {0}", sum);
        }

        private static int CalculateNumbers(int num1, int num2)
        {
            int result = num1 + num2;
            return result;
        }

        private static void Print(string str, int num)
        {
            Console.WriteLine("My name is : {0}", str);
        }
    }
}
