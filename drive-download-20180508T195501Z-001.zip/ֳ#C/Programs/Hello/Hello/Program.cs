﻿/*/*using System*/*/;

namespace Hello
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("The sum of {0} and {1} is {2}. 12,23, 12+ 23");
        }
    }
}
