﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrintNameAndAverage
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter your name");
            string name = Console.ReadLine();
            Console.Write("Enter your age:");
            int age = int.Parse(Console.ReadLine());
            Print(name, age); // הכרזה על הפונקציה.

            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            //int sum = CalculateNumbers(num1, num2); // מקבלת num1 וnum2 ומחברת אותם.
            int avg = CalculateNumbers(num1, num2);
            Console.WriteLine("The avg is {0} ", avg);
            //Console.WriteLine("The result is {0}", sum);  // מדפיס את הsum
            Console.ReadKey();
        }                                           // מחזירה לsum 
                                                    // משתנה sum מסוג int


        private static int CalculateNumbers(int num1, int num2)  //  תחזיר את התוצאה.
        {                                                         // מקבלת num1 num2 
            int avg = (num1 + num2) / 2;
            return avg;
            //int result = num1 + num2;
            //return result;    //num1 + num2; //reurn, פונקציה מחזירה ערך. משתמשים במילה שמורה
                              // return result; מחזיר את זה לפונקציה הראשית
        }                         // מחזירה את הסכום.




        private static void Print(string name, int age)  // אפשר לקרוא למשתנים בstr וnum ולשנות בהתאמה.
        {
            Console.WriteLine("My name is: {0}", name);  // מס' הפרמטרים חייב להיותתואם. 
        }

    }
}