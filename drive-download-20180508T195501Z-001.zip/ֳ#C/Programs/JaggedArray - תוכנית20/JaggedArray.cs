using System;
	class MyJaggedSample
	{
		static void Main()
		{
			Random rnd = new Random();

			int[][] jagged	= new int[10][];
			
			for	(int y=0;y < jagged.Length;y++)
				jagged[y] =	new	int[rnd.Next(10)+1];
			
			for	(int y=0;y < jagged.Length;y++)
				for(int	x=0;x<jagged[y].Length;x++)
					jagged[y][x] = rnd.Next(100);
			
			Console.WriteLine("Array of Arrays (Jagged) Array");
			
			for	(int y=0;y < jagged.Length;y++)
			{
				for(int	x=0;x<jagged[y].Length;x++)
					Console.Write("{0,4}", jagged[y][x]);
				Console.WriteLine();
			}
		}
}
