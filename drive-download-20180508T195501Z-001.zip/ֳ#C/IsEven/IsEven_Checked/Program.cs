﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IsEven
{
    class Program
    {
        //התוכנית טובה ראה את הערותיי בנוגע לפונקציה שבודקת ומשווה בין המערכים
        static void Main(string[] args)
        {

            int[] firstarray = new int[5];  // הכרזה על מערך ראשון בגודל 5

            int[] secondarray = new int[5]; // הכרזה על מערך שני בגודל 5.

            CreateArray(firstarray, secondarray); // הפונקציה מקבלת את הפרמטרים first array וsecondarray

            PrintArray(firstarray, secondarray); // הדפסת המערכים באמצעות פונקציה.

            Console.WriteLine(Numbers(firstarray, secondarray));  // הדפסת הערך אמת או שקר.

        }


        //הפונקציה בסדר והיא תעבוד. אך היא מידי מסורבלת
        
        public static bool Numbers (int[] array1, int[] array2)
        {
            //int count = 0;
            for (int i = 0; i < array1.Length; i++)
            {
                if (array1[i] != array2[i])
                {
                    return false;                    
                }

                else
                {
                    return true;
                }
            }

           
            return true;
        }

        //מה דעתך על הפונקציה הבאה
        //static bool IsEvenArr(int[] array1, int[] array2)
        //{
        //    int x = 0;
        //    for (int i = 0; i < array1.Length; i++)
        //    {
        //        if (array1[i] != array2[x])
        //        {
        //            return false;
        //        }
        //        x++;
        //    }
        //    return true;

        //}


        // פונקציה הקולטת 5 מספרים ויוצרת מערך.  
        static void CreateArray(int[] array1, int[] array2)
        {
           
            for (int i = 0; i < array1.Length; i++)
            {
                Console.Write("Please insert numbers of array1: ");
                array1[i] = int.Parse(Console.ReadLine());
            }
            Console.Write("\n");


            for (int j = -0; j < array2.Length; j++) //למה הוספת - לפני ה-0 אני מניח שמדובר בטעות סופרים
            {
                //int num = 0;
                Console.Write("Enter number of array2:");
                array2[j] = int.Parse(Console.ReadLine());

            }


            //Array1 = array1[5];
            //Array2 = array2[5];
        }


        public static void PrintArray(int[] array1, int[] array2)
        {
            //int num = 0, num2 = 0;

            for (int i = 0; i < array1.Length; i++)
            {
                Console.WriteLine("current number is {0}", array1[i]);

            }


            Console.Write("\n");

            for (int j = 0; j < array2.Length; j++)
            {
                Console.WriteLine("current number is {0}", array2[j]);

            }


        }

    }
}